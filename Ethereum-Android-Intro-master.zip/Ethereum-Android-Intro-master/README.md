# Ethereum-Android-Intro
A quick intro demonstrating working with Ethereum on Android using Infura and Web3j from [this article](https://medium.com/datadriveninvestor/an-introduction-to-ethereum-development-on-android-using-web3j-and-infura-763940719997)
